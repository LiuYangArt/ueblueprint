<img width="2938" height="1347" alt="image" src="https://github.com/user-attachments/assets/cb0943c4-db46-41bb-9a8f-8e0b23d980ea" /><img width="2286" height="1891" alt="image" src="https://github.com/user-attachments/assets/8bd92a41-5cd7-4478-af7e-387494b31889" />


<br>
- 基于 https://github.com/barsdeveloper/ueblueprint 项目， 接入ai功能
- 这是一个开发中的实验性项目，很多功能都可能出问题。 

## 安装
下载整个项目
<br><img width="699" height="663" alt="image" src="https://github.com/user-attachments/assets/d7ccbb21-0782-4fdd-9b9b-335a49410d18" />

- 0_install.bat 安装脚本
- 1_run_server.bat 运行脚本
- 运行后打开http://localhost:8080/ai-demo.html  ai功能测试页
- 需要使用自己的api key， 目前接了[yunwu](https://yunwu.ai/register?aff=VE3i) | [gptgod](https://gptgod.site/#/register?invite_code=5ax35dxlk4bys0j7jnzqypwkc) ， 使用openai兼容模式的api应该都可以


## 使用
- 支持蓝图模式和材质模式
- chat模式根据当前graph中的节点内容作为上下文进行回答，可对选中节点单独作为上下文
- generate 模式生成节点


